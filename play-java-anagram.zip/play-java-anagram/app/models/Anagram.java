package models;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.ArrayList;


public class Anagram {

    public static char[] charArray;
	public LinkedHashMap<String,Integer> dictionary = new LinkedHashMap<String, Integer>();
	static ArrayList<String> list = new ArrayList<String>();

	/*
	 * Function - Anagram
	 * The constructor reads in the text file
	 */
	public Anagram()
	{		
    	try 
    	{
			this.readTextFile();
		} 
    	catch (Exception e) 
    	{
			e.printStackTrace();
		}
	}
	
	/*
	 * Function - readTextFile
	 * This function reads the text file and builds the dictionary/hashmap of the words
	 * ToDo -  Need to add the file path as a parameter when starting service
	 */
	public void readTextFile() throws IOException 
	{
		BufferedReader reader = new BufferedReader(new FileReader(new File("wordsEn.txt")));
		String inputLine = null;
		
		while((inputLine = reader.readLine()) != null) {
			// Split the input line.
			String[] words = inputLine.split("\\s+");
			
			// Ignore empty lines.
			if(inputLine.equals(""))
				continue;
			int i = 1;
			for(String word: words) {
				// Remove any commas and dots.
				word = word.replace(".", "");
				word = word.replace(",", "");
				
				if(!dictionary.containsKey(word)) {
					dictionary.put(word, i);
					i++;
				}
			}
		}
		reader.close();
	}

	/*
	 * Function - start
	 * This function starts the process of finding the anagrams and building the list
	 */	
    public ArrayList<String> start(String word) {
    	Anagram.list.clear();
        charArray = word.toCharArray();
        if(dictionary.containsKey(word))
        {
        	doAnagram(charArray.length);
        	Anagram.list.remove(word); // removing the original word from the anagram list
        	return (Anagram.list);
        }
        else
        	return (null);
    }

    /*
     * Function - doAnagram
     * 
     */
    public void doAnagram(int newsize) {
        if (newsize == 1) {
            return;
        }
        for (int i = 0; i < newsize; i++) {
            doAnagram(newsize - 1);
            if (newsize == 2) {
                addToList();
            }
            changeOrder(newsize);
        }
    }

    /*
     * Function - changeOrder
     */
    public void changeOrder(int newsize) {
        int j;
        int pointAt = charArray.length - newsize;
        char temp = charArray[pointAt];

        for (j = pointAt + 1; j < charArray.length; j++) {
            charArray[j - 1] = charArray[j];
        }

        charArray[j - 1] = temp;

    }
   
    /*
     * Function - addToList
     * Convert the char array into String. Add to the list of Anagrams if the word is in
     * text list and not already in the list
     */
    public void addToList()
    {
        String str = String.valueOf(charArray);
        if(dictionary.containsKey(str) && !list.contains(str)) {
        	list.add(str);
        }
    }
    
}
