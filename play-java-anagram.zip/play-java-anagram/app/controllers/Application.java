package controllers;

import static play.libs.Json.toJson;

import java.util.ArrayList;

import models.Anagram;
import play.*;
import play.mvc.*;
import views.html.*;

public class Application extends Controller {

    public Result index() {
        return ok(index.render("Your new application is ready."));
    }

    public Result getAnagram(String str){
    	Anagram ang = new Anagram();
    	ArrayList<String> lst = ang.start(str);
    	if (lst == null)
    		return notFound();
    	else
    		return ok(toJson(lst));
    }
}
